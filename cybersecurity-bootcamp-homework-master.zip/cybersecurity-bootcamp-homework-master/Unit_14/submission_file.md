# Unit 14
## Justin Cremer

1.  A client-server TCP architecture.
2.  [Protocol]://[Url]/[Path]/[Parameters]
3.  Parameters  
4.  Request line, Header, Body 
5.  [400..499] :: Client errors && [500..599] :: Server errors
6.  Get and Post
7.  Post
8.  Body
9.  Body
10. Easy to read and modify request headers and params.
11. -X --request
12. -H --header
13. -D --dump-header
14. Get
15. Set-Cookie
16. Cookie
17. Post
18. Content-Type: application/x-www-form-urlencoded
19. No
20. Uname & Passwd ( A login attempt )
21. 200 OK
22. Apache
23. Yes => SessionID=5
24. HTML
25. The X-* headers correspond with server side security variables
26. I'm sure there's some student guide specific answer this question is
    targeting, but I can't find it.  A microservice; however, can be made of a
    number of components, but generally includes an enclosed api.
27. API
28. Virtualization / Containerization
29. Docker-compose or Kubernetes
30. .yaml or .yml
31. SELECT * FROM customers
32. INSERT INTO [columns] VALUES [values] 
33. This will recursively delete all values in the selected rows
