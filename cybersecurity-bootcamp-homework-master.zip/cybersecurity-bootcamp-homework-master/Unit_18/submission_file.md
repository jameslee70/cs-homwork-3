# Unit 18
## Justin Cremer

### All screenshots located in the images directory

#### Step 1:
-   The approximate date and time of the attack is 02/23/2020 at 2:30pm.  
-   It took the system nine hours to fully recover.

#### Step 3:
-   My determined baseline is 20 logins in and hour and my threshold is a count
greater than or equal to 30.

